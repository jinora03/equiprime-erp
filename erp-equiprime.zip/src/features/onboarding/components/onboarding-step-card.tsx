import { forwardRef } from "react";
import type { CSSProperties } from "react";
import { ArrowLeft, ArrowRight, Check } from "lucide-react";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { OnboardingStep } from "../types";

interface OnboardingStepCardProps {
  step: OnboardingStep;
  index: number;
  total: number;
  isMobile: boolean;
  style?: CSSProperties;
  onBack: () => void;
  onNext: () => void;
  onSkip: () => void;
}

export const OnboardingStepCard = forwardRef<HTMLElement, OnboardingStepCardProps>(
  function OnboardingStepCard(
    { step, index, total, isMobile, style, onBack, onNext, onSkip },
    ref,
  ) {
    const Icon = step.icon;
    const isLast = index === total - 1;
    const titleId = `onboarding-title-${step.id}`;
    const descriptionId = `onboarding-description-${step.id}`;

    return (
      <section
        ref={ref}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={descriptionId}
        tabIndex={-1}
        className={cn(
          "pointer-events-auto z-[92] overflow-y-auto border border-border bg-popover text-popover-foreground shadow-elevated focus:outline-none",
          isMobile
            ? "fixed inset-x-4 bottom-4 max-h-[calc(100dvh-2rem)] rounded-lg p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))]"
            : "fixed w-[380px] max-h-[calc(100dvh-2.5rem)] rounded-lg p-6",
        )}
        style={isMobile ? undefined : style}
      >
        <div className="flex items-start gap-4">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-brand-emphasis/10 text-brand-emphasis">
            <Icon className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex items-center justify-between gap-3">
              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                {index + 1} of {total}
              </p>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="h-7 px-2 text-xs text-muted-foreground"
                onClick={onSkip}
              >
                Skip
              </Button>
            </div>
            <h2 id={titleId} className="mt-1.5 text-base font-semibold">
              {step.title}
            </h2>
            <p
              id={descriptionId}
              className="mt-2 text-sm leading-6 text-muted-foreground"
            >
              {step.description}
            </p>
          </div>
        </div>

        <div className="mt-5 flex items-center gap-1.5" aria-hidden>
          {Array.from({ length: total }, (_, dotIndex) => (
            <span
              key={dotIndex}
              className={cn(
                "h-1.5 rounded-full transition-all motion-reduce:transition-none",
                dotIndex === index ? "w-5 bg-brand-emphasis" : "w-1.5 bg-muted-foreground/25",
              )}
            />
          ))}
        </div>

        <div className="mt-5 flex items-center justify-between gap-3 border-t border-border/60 pt-4">
          <Button
            type="button"
            variant="outline"
            size="sm"
            className={cn(isMobile && "min-h-10")}
            onClick={onBack}
            disabled={index === 0}
          >
            <ArrowLeft className="h-4 w-4" /> Back
          </Button>
          <Button
            type="button"
            size="sm"
            className={cn(isMobile && "min-h-10")}
            onClick={onNext}
          >
            {isLast ? (
              <>
                <Check className="h-4 w-4" /> Finish
              </>
            ) : (
              <>
                Next <ArrowRight className="h-4 w-4" />
              </>
            )}
          </Button>
        </div>
      </section>
    );
  },
);
